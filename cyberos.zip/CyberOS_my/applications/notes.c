#include <stdint.h>
#include <string.h>
#include "filesystem.h"
#include "gui.h"

// Funkcja do rysowania interfejsu użytkownika aplikacji Notatnik
void draw_notes_ui() {
    draw_window(10, 10, 300, 180, "CyberOS My Notes");
    draw_button(20, 40, 60, 20, "Create Note");
    draw_button(100, 40, 60, 20, "View Notes");
    draw_button(180, 40, 60, 20, "Delete Note");
}

// Funkcja do tworzenia nowej notatki
void create_note() {
    print_string("Podaj treść notatki: ");
    
    char note[1024];
    gets(note);  // Pobranie tekstu notatki
    
    // Zapisanie notatki do pliku
    int result = fs_create_file("/notes", "note.txt", (uint8_t*)note, strlen(note));
    if (result == 0) {
        print_string("Notatka została zapisana pomyślnie.\n");
    } else {
        print_string("Wystąpił błąd przy zapisywaniu notatki.\n");
    }
}

// Funkcja do wyświetlania zapisanych notatek
void view_notes() {
    char note[1024];
    
    // Zakładając, że wszystkie notatki są zapisane w tym samym pliku, np. "note.txt"
    int result = fs_read_file("/notes", "note.txt", (uint8_t*)note, sizeof(note));
    if (result == 0) {
        print_string("Zawartość notatki:\n");
        print_string(note);  // Wyświetlanie zawartości notatki
    } else {
        print_string("Brak zapisanych notatek.\n");
    }
}

// Funkcja do usuwania notatki
void delete_note() {
    // Usuwanie pliku "note.txt"
    int result = fs_delete_file("/notes", "note.txt");
    if (result == 0) {
        print_string("Notatka została usunięta pomyślnie.\n");
    } else {
        print_string("Nie udało się usunąć notatki.\n");
    }
}

// Główna funkcja aplikacji Notatnik
void notes_main() {
    draw_notes_ui();  // Rysowanie interfejsu
    
    while (1) {
        // Czekamy na interakcję z użytkownikiem
        char choice = get_char();
        
        if (choice == '1') {
            create_note();  // Tworzenie nowej notatki
        } else if (choice == '2') {
            view_notes();  // Wyświetlanie zapisanych notatek
        } else if (choice == '3') {
            delete_note();  // Usuwanie notatki
        } else {
            print_string("Nieznana opcja.\n");
        }
    }
}
