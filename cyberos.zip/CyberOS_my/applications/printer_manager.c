#include <stdint.h>
#include <string.h>
#include "printer.h"
#include "gui.h"

// Funkcja rysująca interfejs menedżera drukarki
void draw_printer_manager_ui() {
    draw_window(10, 10, 300, 180, "CyberOS My Printer Manager");
    draw_button(20, 40, 60, 20, "Print");
    draw_button(100, 40, 60, 20, "Preview");
    draw_button(180, 40, 60, 20, "Cancel");
}

// Funkcja do wybierania drukarki (symulacja)
int select_printer() {
    print_string("Wybieram drukarkę...\n");
    // W prawdziwej aplikacji możemy dodać kod, który wybiera drukarkę z listy dostępnych.
    return 0;  // Symulacja, zakładając, że zawsze wybieramy pierwszą drukarkę
}

// Funkcja do podglądu dokumentu przed drukowaniem
void preview_document(const char* document) {
    print_string("Podgląd dokumentu:\n");
    print_string(document);  // Symulujemy podgląd przez wypisanie treści dokumentu
    print_string("\nCzy chcesz kontynuować? (y/n): ");
    
    char choice = get_char();
    if (choice == 'n') {
        print_string("Anulowanie drukowania.\n");
        return;
    } else if (choice != 'y') {
        print_string("Nieznana opcja, anulowanie.\n");
        return;
    }
    print_string("Kontynuowanie drukowania...\n");
}

// Funkcja do zarządzania procesem drukowania
void print_document_with_manager(const char* document) {
    int printer = select_printer();  // Wybór drukarki (symulacja)
    if (printer < 0) {
        print_string("Brak dostępnej drukarki.\n");
        return;
    }

    // Wykonanie podglądu dokumentu
    preview_document(document);

    // Drukowanie dokumentu
    print_string("Rozpoczynanie drukowania dokumentu...\n");
    print_document(document);  // Funkcja drukująca
    print_string("Dokument został wydrukowany pomyślnie.\n");
}

// Główna funkcja menedżera drukarki
void printer_manager_main() {
    draw_printer_manager_ui();  // Rysowanie interfejsu użytkownika
    print_string("Witaj w menedżerze drukarki CyberOS My!\n");

    char document[1024];
    print_string("Podaj dokument do wydruku: ");
    gets(document);  // Pobranie tekstu dokumentu od użytkownika
    
    if (strlen(document) == 0) {
        print_string("Nie podano żadnego dokumentu.\n");
        return;
    }

    // Uruchomienie procesu drukowania z podglądem
    print_document_with_manager(document);

    while (1) {
        // Obsługa dodatkowych funkcji menedżera drukarki (np. ponowne drukowanie, wybór ustawień)
        // W prawdziwej aplikacji tutaj moglibyśmy dodać więcej interakcji z użytkownikiem
    }
}
