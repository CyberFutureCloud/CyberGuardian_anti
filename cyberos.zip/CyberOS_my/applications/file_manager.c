#include <stdint.h>
#include <string.h>
#include "gui.h"
#include "filesystem.h"

void draw_file_manager_ui() {
    // Rysowanie okna menedżera plików
    draw_window(10, 10, 300, 180, "CyberOS My File Manager");

    // Wyświetlanie przycisków dla operacji
    draw_button(20, 40, 60, 20, "Create File");
    draw_button(100, 40, 60, 20, "Create Folder");
    draw_button(180, 40, 60, 20, "Delete");
    
    // Dodaj wyświetlanie listy plików i folderów (na razie w formie tekstowej)
    print_string("Pliki i foldery:\n");
    print_string("1. file1.txt\n");
    print_string("2. folder1\n");
}

void create_file(const char* filename) {
    // Funkcja do tworzenia pliku
    uint8_t file_data[] = {};  // Przykładowe dane pliku
    fs_create_file("/home", filename, file_data, sizeof(file_data));
    print_string("Plik stworzony pomyślnie!\n");
}

void create_folder(const char* foldername) {
    // Funkcja do tworzenia folderu
    fs_create_folder("/home", foldername);
    print_string("Folder stworzony pomyślnie!\n");
}

void delete_item(const char* item_name) {
    // Funkcja do usuwania pliku lub folderu
    if (fs_delete_item("/home", item_name)) {
        print_string("Element usunięty pomyślnie!\n");
    } else {
        print_string("Błąd przy usuwaniu elementu.\n");
    }
}

void file_manager_main() {
    draw_file_manager_ui();  // Rysowanie GUI

    while (1) {
        // Zakładając, że istnieje funkcja do wykrywania kliknięcia przycisków:
        char choice = get_char();  // Pobierz wybór użytkownika (np. z klawiatury)

        if (choice == '1') {
            // Tworzenie pliku
            print_string("Podaj nazwę pliku do utworzenia: ");
            char filename[100];
            gets(filename);  // Pobierz nazwę pliku
            create_file(filename);  // Stwórz plik
        } else if (choice == '2') {
            // Tworzenie folderu
            print_string("Podaj nazwę folderu do utworzenia: ");
            char foldername[100];
            gets(foldername);  // Pobierz nazwę folderu
            create_folder(foldername);  // Stwórz folder
        } else if (choice == '3') {
            // Usuwanie pliku lub folderu
            print_string("Podaj nazwę pliku lub folderu do usunięcia: ");
            char item_name[100];
            gets(item_name);  // Pobierz nazwę elementu do usunięcia
            delete_item(item_name);  // Usuń element
        }
    }
}
