#include <stdint.h>
#include "gui.h"  // Biblioteka z funkcjami GUI (w tym draw_window i print_string)

// Symulacja klatki wideo (na przykład obrazek 320x240 pikseli)
extern uint8_t video_frame[];  // Tablica zawierająca klatkę wideo

// Funkcja do odtwarzania filmu
void video_player_main() {
    // Rysowanie okna aplikacji
    draw_window(10, 10, 300, 180, "CyberOS My Video Player");
    print_string("Witaj w odtwarzaczu filmow CyberOS My!\n");
    
    // Wczytywanie filmu (symulacja)
    print_string("Wczytywanie filmu...\n");

    // Przykład prostego odtwarzania - wyświetlanie klatek co 1 sekundę
    // Możemy użyć funkcji sleep() lub innej funkcji do opóźniania wyświetlania

    int frame_count = 0;
    while (1) {
        // Co każdą klatkę filmu, rysuj aktualny obraz
        print_string("Odtwarzanie klatki: ");
        print_int(frame_count);  // Wyświetlamy numer klatki

        // Wyświetlanie klatki wideo
        set_wallpaper(video_frame);  // Funkcja wyświetlająca klatkę filmu

        // Przewijanie filmu (symulacja opóźnienia na 1 sekundę)
        // W prawdziwej aplikacji wideo, zamiast tego powinno być wczytywanie następnej klatki
        frame_count++;
        if (frame_count >= MAX_FRAMES) {
            frame_count = 0;  // Powrót do pierwszej klatki
        }

        // Dodajemy opóźnienie (symulacja 1 sekundy, w prawdziwej aplikacji użyj odpowiednich funkcji)
        delay(1000);  // Opóźnienie na 1000ms (1 sekunda)
    }
}
