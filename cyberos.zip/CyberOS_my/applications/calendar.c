#include <stdint.h>
#include <string.h>
#include "network.h"
#include "gui.h"
#include "calendar_data.h"  // Zawiera dane kalendarza, np. wydarzenia

// Stałe
#define MAX_EVENTS 10

// Struktura wydarzenia
typedef struct {
    char date[11];  // Format: YYYY-MM-DD
    char event[256]; // Opis wydarzenia
} Event;

// Zmienna globalna przechowująca wydarzenia
Event events[MAX_EVENTS];
int total_events = 0;  // Liczba wydarzeń

// Funkcja inicjalizująca kalendarz
void calendar_init() {
    total_events = 0;
    memset(events, 0, sizeof(events));
}

// Funkcja rysująca kalendarz na podstawie pobranych danych
void draw_calendar(int month, int year) {
    draw_window(10, 10, 400, 300, "CyberOS My Calendar");
    
    // Wyświetlenie nazwy miesiąca
    char month_str[20];
    snprintf(month_str, sizeof(month_str), "Miesiąc: %d/%d", month, year);
    print_string(month_str);
    
    // Wyświetlanie dni w kalendarzu (zamiast tego możesz mieć tablicę z dniami tygodnia)
    for (int i = 1; i <= 31; i++) {
        print_string("Dzień: ");
        print_int(i);
        print_string("\n");

        // Sprawdzamy, czy dla danego dnia są wydarzenia
        for (int j = 0; j < total_events; j++) {
            if (strncmp(events[j].date, "2025-01-20", 10) == 0) {
                // Wyświetl wydarzenia
                print_string("  Wydarzenie: ");
                print_string(events[j].event);
            }
        }
    }
}

// Funkcja do pobierania danych kalendarza z serwera
void fetch_calendar_data() {
    print_string("Pobieranie danych kalendarza...\n");

    // Symulacja zapytania HTTP do serwera (np. GET)
    const char* request = "GET /calendar/data HTTP/1.1\r\nHost: calendar.cyberos.com\r\n\r\n";
    network_send(request, strlen(request), "calendar.cyberos.com", 80);

    // Odbieranie odpowiedzi
    char buffer[1024];
    memset(buffer, 0, sizeof(buffer));
    network_receive(buffer, sizeof(buffer));

    // Symulacja parsowania odpowiedzi JSON (przykład danych)
    // W prawdziwej aplikacji będziesz musiał sparsować odpowiedź (np. JSON -> struktura)
    snprintf(events[0].date, sizeof(events[0].date), "2025-01-20");
    snprintf(events[0].event, sizeof(events[0].event), "Spotkanie z klientem");
    total_events++;

    snprintf(events[1].date, sizeof(events[1].date), "2025-01-21");
    snprintf(events[1].event, sizeof(events[1].event), "Wykład na uczelni");
    total_events++;
}

// Funkcja główna kalendarza
void calendar_main() {
    calendar_init();
    fetch_calendar_data();  // Pobranie danych kalendarza
    
    // Załóżmy, że obecny miesiąc to styczeń 2025
    int current_month = 1;
    int current_year = 2025;

    // Rysowanie kalendarza
    draw_calendar(current_month, current_year);

    while (1) {
        // Logika do nawigacji po miesiącach, wyświetlanie szczegółów wydarzeń itp.
        // Możesz dodać tutaj obsługę przycisków (np. poprzedni/następny miesiąc)

        // W przykładowym przypadku po prostu rysujemy kalendarz
        draw_calendar(current_month, current_year);
    }
}
