#include <stdint.h>
#include <stdio.h>
#include <string.h>

// Funkcja do rysowania okna (symulacja)
void draw_window(int x, int y, int width, int height, const char* title) {
    printf("Window: %s [%d,%d,%d,%d]\n", title, x, y, width, height);
}

// Funkcja do wyświetlania tekstu na ekranie (symulacja)
void print_string(const char* str) {
    printf("%s\n", str);
}

// Funkcja do wczytywania tekstu (symulacja)
void get_string(char* str, uint32_t max_size) {
    fgets(str, max_size, stdin);
    str[strcspn(str, "\n")] = 0;  // Usunięcie znaku nowej linii
}

// Funkcja do zmiany daty i godziny
void change_date_time() {
    print_string("Wprowadź nową datę (DD-MM-YYYY): ");
    char new_date[11];
    get_string(new_date, sizeof(new_date));
    
    print_string("Wprowadź nową godzinę (HH:MM:SS): ");
    char new_time[9];
    get_string(new_time, sizeof(new_time));
    
    print_string("Data i godzina zostały zmienione.\n");
    // W prawdziwej aplikacji, tutaj zmienialibyśmy systemową datę i godzinę
}

// Funkcja do zmiany urządzenia startowego
void change_boot_device() {
    print_string("Wybierz urządzenie startowe:");
    print_string("1. HDD");
    print_string("2. USB");
    print_string("3. Network");

    char choice = getchar();
    getchar(); // Czyszczenie bufora po getchar()

    switch (choice) {
        case '1':
            print_string("Urządzenie startowe ustawione na HDD.\n");
            break;
        case '2':
            print_string("Urządzenie startowe ustawione na USB.\n");
            break;
        case '3':
            print_string("Urządzenie startowe ustawione na Network.\n");
            break;
        default:
            print_string("Błędny wybór!\n");
            break;
    }
}

// Funkcja do włączania/wyłączania wirtualizacji
void toggle_virtualization() {
    print_string("Włącz wirtualizację? (t/n): ");
    char choice = getchar();
    getchar(); // Czyszczenie bufora po getchar()

    if (choice == 't' || choice == 'T') {
        print_string("Wirtualizacja została włączona.\n");
    } else {
        print_string("Wirtualizacja została wyłączona.\n");
    }
}

// Główna funkcja BIOS
void bios_main() {
    draw_window(10, 10, 300, 180, "BIOS Setup");
    print_string("Witaj w BIOS setup!\n");
    print_string("Tutaj możesz zmienić ustawienia systemu.\n");

    while (1) {
        print_string("Wybierz opcję:");
        print_string("1. Zmień datę i godzinę");
        print_string("2. Zmień urządzenie startowe");
        print_string("3. Włącz/wyłącz wirtualizację");
        print_string("4. Zakończ");

        char choice = getchar();
        getchar(); // Czyszczenie bufora po getchar()

        switch (choice) {
            case '1':
                change_date_time();
                break;
            case '2':
                change_boot_device();
                break;
            case '3':
                toggle_virtualization();
                break;
            case '4':
                print_string("Zakończono ustawienia BIOS.\n");
                return; // Zakończenie pracy BIOS
            default:
                print_string("Błędny wybór, spróbuj ponownie.\n");
                break;
        }
    }
}

int main() {
    bios_main();  // Uruchomienie BIOS setup
    return 0;
}
