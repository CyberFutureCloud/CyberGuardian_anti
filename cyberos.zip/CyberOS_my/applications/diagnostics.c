#include <stdint.h>
#include <string.h>
#include <stdio.h> // Dla funkcji snprintf

// Funkcja do rysowania okna (symulacja)
void draw_window(int x, int y, int width, int height, const char* title) {
    printf("Window: %s [%d,%d,%d,%d]\n", title, x, y, width, height);
}

// Funkcja do wyświetlania tekstu na ekranie (symulacja)
void print_string(const char* str) {
    printf("%s\n", str);
}

// Funkcja do wyświetlania liczb (symulacja)
void print_int(int value) {
    printf("%d\n", value);
}

// Funkcja symulująca monitorowanie CPU, pamięci i dysku
void monitor_resources() {
    // Symulacja zużycia zasobów
    uint8_t cpu_usage = 25;      // Symulacja zużycia CPU
    uint8_t memory_usage = 40;   // Symulacja zużycia pamięci
    uint8_t disk_usage = 60;     // Symulacja zużycia dysku

    // Wyświetlanie wyników monitorowania zasobów
    print_string("Monitorowanie zasobów systemowych:");

    print_string("CPU Usage: ");
    print_int(cpu_usage);
    print_string("%");

    print_string("Memory Usage: ");
    print_int(memory_usage);
    print_string("%");

    print_string("Disk Usage: ");
    print_int(disk_usage);
    print_string("%");
}

// Funkcja do wyświetlania diagnostyki systemu
void perform_diagnostics() {
    print_string("Diagnostyka sprzętu:");
    // Symulacja diagnostyki
    print_string("Sprawdzanie stanu CPU... OK");
    print_string("Sprawdzanie pamięci RAM... OK");
    print_string("Sprawdzanie przestrzeni dyskowej... OK");
    print_string("Sprawdzanie połączenia sieciowego... OK");
}

// Funkcja do odświeżania wyników monitorowania
void refresh_monitoring() {
    print_string("Odświeżanie wyników monitorowania...");
    monitor_resources();
}

void diagnostics_main() {
    draw_window(10, 10, 300, 180, "CyberOS My Diagnostics");
    print_string("Witaj w narzędziach diagnostycznych CyberOS My!\n");

    // Monitorowanie zasobów
    monitor_resources();
    
    // Opcja diagnostyki systemu
    print_string("Wykonaj pełną diagnostykę systemu? (t/n): ");
    
    char choice = getchar(); // Wczytanie opcji użytkownika
    
    if (choice == 't' || choice == 'T') {
        perform_diagnostics(); // Wykonaj diagnostykę
    }

    // Opcja odświeżania wyników monitorowania
    print_string("Odśwież wyniki monitorowania? (t/n): ");
    choice = getchar(); // Wczytanie opcji użytkownika

    if (choice == 't' || choice == 'T') {
        refresh_monitoring(); // Odśwież wyniki monitorowania
    }

    while (1) {
        // Można dodać inne interakcje, np. powtarzanie monitorowania po jakimś czasie
    }
}

int main() {
    diagnostics_main(); // Uruchomienie głównej funkcji diagnostycznej
    return 0;
}
