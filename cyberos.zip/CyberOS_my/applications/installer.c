#include <stdint.h>
#include <string.h>
#include "filesystem.h"
#include "http_client.h"  // Załóżmy, że masz bibliotekę do obsługi HTTP

// Funkcja do pobierania pliku z internetu
int download_file(const char* url, const char* dest_path) {
    // Pobieranie pliku z internetu i zapisanie go lokalnie
    uint8_t buffer[1024];  // Bufor do pobierania danych
    size_t bytes_received = 0;
    FILE* file = fopen(dest_path, "wb");
    if (file == NULL) {
        return 0; // Błąd otwierania pliku
    }

    // Pobieranie pliku za pomocą HTTP (tutaj załóżmy, że masz funkcję do pobierania pliku)
    if (http_get(url, buffer, sizeof(buffer), &bytes_received) != 0) {
        fclose(file);
        return 0; // Błąd pobierania pliku
    }

    fwrite(buffer, 1, bytes_received, file);
    fclose(file);

    return 1; // Sukces
}

// Funkcja instalująca aplikację z internetu
void install_application_from_url(const char* app_name, const char* url) {
    char path[256];
    snprintf(path, sizeof(path), "/apps/%s.bin", app_name);  // Zapisujemy aplikację do katalogu /apps

    if (download_file(url, path)) {
        print_string("Aplikacja została pobrana i zainstalowana pomyślnie.\n");
    } else {
        print_string("Błąd podczas pobierania aplikacji.\n");
    }
}

// Funkcja główna instalatora
void installer_main() {
    draw_window(10, 10, 300, 180, "CyberOS My Installer");
    print_string("Wybierz aplikację do zainstalowania:\n");
    print_string("1. Opera\n");
    print_string("2. Firefox\n");
    
    char choice = get_char(); // Oczekiwanie na wybór użytkownika
    
    // Wybór aplikacji i URL do pobrania
    if (choice == '1') {
        // URL do pobrania Opery
        const char* opera_url = "http://example.com/opera.bin"; // Przykładowy URL
        install_application_from_url("opera", opera_url);
    } else if (choice == '2') {
        // URL do pobrania Firefoxa
        const char* firefox_url = "http://example.com/firefox.bin"; // Przykładowy URL
        install_application_from_url("firefox", firefox_url);
    } else {
        print_string("Niepoprawny wybór. Spróbuj ponownie.\n");
    }
}
