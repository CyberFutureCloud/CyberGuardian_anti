#include <stdint.h>
#include <string.h>
#include "filesystem.h"

void terminal_main() {
    draw_window(10, 10, 300, 180, "Terminal");
    print_string("Witaj w terminalu CyberOS My!\n");
    
    char command[256];
    while (1) {
        print_string("CyberOS My> ");
        gets(command);

        if (strcmp(command, "ls") == 0) {
            print_string("Lista plików:\n");
            // Kod wyświetlania listy plików
        } else if (strncmp(command, "cat", 3) == 0) {
            char filename[32];
            sscanf(command + 4, "%s", filename);
            struct file* file = fs_find_file("/", filename);
            if (file) {
                print_string("Zawartość pliku: ");
                print_string((char*)file->content);
                print_string("\n");
            } else {
                print_string("Plik nie znaleziony.\n");
            }
        } else if (strcmp(command, "exit") == 0) {
            break;
        } else {
            print_string("Nieznane polecenie.\n");
        }
    }
}
