#include <stdint.h>
#include <string.h>
#include "gui.h"

#define MAX_URL_LENGTH 256
#define HISTORY_SIZE 10

// Zmienna przechowująca bieżący URL oraz historię
char current_url[MAX_URL_LENGTH] = "http://home.com";
char previous_url[MAX_URL_LENGTH] = "";
char history[HISTORY_SIZE][MAX_URL_LENGTH];
int history_index = 0;

// Zmienna dla pasku adresu
char address_bar[MAX_URL_LENGTH] = "http://home.com";

// Funkcja rysująca interfejs przeglądarki
void draw_browser_ui() {
    draw_window(10, 10, 400, 300, "CyberOS My Browser");

    // Pasek adresu
    draw_text(20, 20, "Adres:");
    draw_input_field(70, 20, 250, 20, address_bar, MAX_URL_LENGTH); // Pole do wpisywania URL

    // Przyciski nawigacyjne
    draw_button(20, 60, 60, 20, "Home");
    draw_button(100, 60, 60, 20, "Back");
    draw_button(180, 60, 60, 20, "Forward");
    draw_button(260, 60, 60, 20, "Refresh");

    // Wyświetlanie aktualnego URL
    draw_text(20, 100, "Current URL:");
    draw_text(120, 100, current_url);
}

// Funkcja dodająca URL do historii
void add_to_history(const char* url) {
    if (history_index < HISTORY_SIZE) {
        strcpy(history[history_index], url);
        history_index++;
    } else {
        // Jeżeli historia jest pełna, przesuwamy wpisy i dodajemy nowy
        for (int i = 1; i < HISTORY_SIZE; i++) {
            strcpy(history[i - 1], history[i]);
        }
        strcpy(history[HISTORY_SIZE - 1], url);
    }
}

// Funkcja nawigacji do nowego URL
void navigate_to_url(const char* url) {
    add_to_history(current_url); // Zapisujemy aktualny URL do historii
    strcpy(current_url, url); // Zmieniamy URL
    draw_browser_ui(); // Rysujemy UI z nowym URL
    printf("Navigating to %s\n", current_url);
}

// Funkcja obsługująca przycisk "Back"
void go_back() {
    if (history_index > 1) {
        history_index--;
        strcpy(current_url, history[history_index - 1]);
        draw_browser_ui(); // Rysujemy UI z poprzednim URL
        printf("Navigating back to %s\n", current_url);
    } else {
        printf("No more history to go back.\n");
    }
}

// Funkcja obsługująca przycisk "Forward"
void go_forward() {
    if (history_index < HISTORY_SIZE && history[history_index][0] != '\0') {
        strcpy(current_url, history[history_index]);
        history_index++;
        draw_browser_ui(); // Rysujemy UI z kolejnym URL
        printf("Navigating forward to %s\n", current_url);
    } else {
        printf("No forward navigation available.\n");
    }
}

// Funkcja obsługująca przycisk "Refresh"
void refresh_page() {
    draw_browser_ui(); // Rysujemy UI z aktualnym URL (symulacja odświeżenia)
    printf("Refreshing %s\n", current_url);
}

// Główna pętla przeglądarki
void browser_main() {
    draw_browser_ui(); // Inicjalne rysowanie UI
    
    while (1) {
        // Sprawdzanie, czy wciśnięto przycisk
        if (button_pressed(20, 60, 60, 20)) {  // "Home" button
            navigate_to_url("http://home.com");
        }
        else if (button_pressed(100, 60, 60, 20)) {  // "Back" button
            go_back();
        }
        else if (button_pressed(180, 60, 60, 20)) {  // "Forward" button
            go_forward();
        }
        else if (button_pressed(260, 60, 60, 20)) {  // "Refresh" button
            refresh_page();
        }
        
        // Sprawdzanie, czy wprowadza się nowy URL w pasku adresu
        if (input_field_changed(70, 20, 250, 20, address_bar, MAX_URL_LENGTH)) {
            navigate_to_url(address_bar);
        }
    }
}
