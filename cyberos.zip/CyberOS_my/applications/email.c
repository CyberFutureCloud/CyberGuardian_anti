#include <stdint.h>
#include <string.h>
#include "network.h"
#include "gui.h"

// Funkcja główna aplikacji e-mail
void email_main() {
    // Rysowanie okna aplikacji
    draw_window(10, 10, 400, 250, "CyberOS My Email");
    print_string("Witaj w aplikacji email CyberOS My!\n");

    // Zbieranie danych od użytkownika
    char to[100], subject[100], body[1024];

    // Pobieranie adresu e-mail
    print_string("Adresat: ");
    fgets(to, sizeof(to), stdin);  // Użycie fgets zamiast gets dla bezpieczeństwa
    to[strcspn(to, "\n")] = 0;  // Usuwamy znak nowej linii z końca stringa

    // Pobieranie tematu e-maila
    print_string("Temat: ");
    fgets(subject, sizeof(subject), stdin);
    subject[strcspn(subject, "\n")] = 0;  // Usuwamy znak nowej linii z końca stringa

    // Pobieranie treści e-maila
    print_string("Tresc: ");
    fgets(body, sizeof(body), stdin);
    body[strcspn(body, "\n")] = 0;  // Usuwamy znak nowej linii z końca stringa

    // Przygotowanie danych e-maila
    char email_data[1224];
    snprintf(email_data, sizeof(email_data), "TO: %s\nSUBJECT: %s\nBODY: %s", to, subject, body);

    // Wysyłanie e-maila
    print_string("Wysylanie e-maila...\n");
    network_send(email_data, strlen(email_data));

    print_string("Email zostal wyslany pomyslnie.\n");

    // Zatrzymujemy aplikację, można dodać interakcje z GUI (np. "Nowy e-mail", "Wyjście")
    while (1) {
        // Dalsza logika aplikacji e-mail
        // Można dodać obsługę przycisków, np. "Wyjście" lub "Nowy e-mail"
    }
}

// Funkcja do wysyłania danych przez sieć (np. HTTP)
void network_send(const char* data, uint32_t size) {
    // Funkcja do wysyłania danych przez sieć (symulacja HTTP lub TCP)
    // Zamiast prawdziwego wysyłania, tutaj zaimplementujemy prostą symulację

    // W prawdziwej aplikacji powinieneś użyć bibliotek do komunikacji SMTP (np. libcurl) lub własnej implementacji SMTP
    printf("Wysyłanie danych e-mail...\n");
    printf("Dane wysłane: %s\n", data);

    // Symulacja odbioru potwierdzenia od serwera e-mail
    printf("Odpowiedz serwera: Email zostal pomyslnie wyslany.\n");
}

