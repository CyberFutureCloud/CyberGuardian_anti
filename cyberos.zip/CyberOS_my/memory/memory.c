#include <stdint.h>
#include <string.h>

#define PAGE_SIZE 4096

uint32_t* create_page_directory() {
    uint32_t* page_directory = (uint32_t*)memory_alloc();
    memset(page_directory, 0, PAGE_SIZE);

    uint32_t cr0;
    asm volatile ("mov %0, %%cr3" : : "r"(page_directory));
    asm volatile ("mov %%cr0, %0" : "=r"(cr0));
    cr0 |= 0x80000000;
    asm volatile ("mov %0, %%cr0" : : "r"(cr0));

    return page_directory;
}

void map_page(uint32_t* page_directory, uint32_t virtual_address, uint32_t physical_address) {
    uint32_t page_directory_index = virtual_address >> 22;
    uint32_t page_table_index = (virtual_address >> 12) & 0x03FF;

    uint32_t* page_table = (uint32_t*)(page_directory[page_directory_index] & 0xFFFFF000);
    if (!page_table) {
        page_table = (uint32_t*)memory_alloc();
        memset(page_table, 0, PAGE_SIZE);
        page_directory[page_directory_index] = (uint32_t)page_table | 0x03;
    }

    page_table[page_table_index] = physical_address | 0x03;
}
