#include <stdint.h>
#include <string.h>
#include "keyboard.h"

void setup() {
    char username[32];
    char timezone[32];
    char language[32];

    set_wallpaper(9); // Ustawienie koloru tapety

    print_string("Konfiguracja systemu\n");

    // Tworzenie konta
    print_string("Podaj nazwe uzytkownika: ");
    gets(username);
    print_string("Witamy, ");
    print_string(username);
    print_string("!\n");

    // Wybór języka
    print_string("Wybierz jezyk (np. EN, PL): ");
    gets(language);
    print_string("Wybrales: ");
    print_string(language);
    print_string("\n");

    // Wybór strefy czasowej
    print_string("Wybierz strefe czasowa: ");
    gets(timezone);
    print_string("Wybrales: ");
    print_string(timezone);
    print_string("\n");
}
