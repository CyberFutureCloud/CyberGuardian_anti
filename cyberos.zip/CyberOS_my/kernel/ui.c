#include <stdint.h>
#include <string.h>

void print_string(const char* str);

void ui_main() {
    print_string("CyberOS My> ");
    char command[128];

    while (1) {
        // Odczytaj komendę użytkownika
        gets(command);

        if (strcmp(command, "help") == 0) {
            print_string("Dostępne komendy:\n");
            print_string("help - wyświetla tę wiadomość\n");
            print_string("mkdir <dirname> - tworzy nowy katalog\n");
            print_string("create <dirname> <filename> <content> - tworzy nowy plik w katalogu\n");
            print_string("read <dirname> <filename> - odczytuje zawartość pliku\n");
        } else if (strncmp(command, "mkdir", 5) == 0) {
            char dirname[32];
            sscanf(command + 6, "%s", dirname);

            if (fs_create_directory(dirname) == 0) {
                print_string("Katalog stworzony pomyślnie\n");
            } else {
                print_string("Błąd przy tworzeniu katalogu\n");
            }
        } else if (strncmp(command, "create", 6) == 0) {
            char dirname[32];
            char filename[32];
            char content[1024];

            sscanf(command + 7, "%s %s %s", dirname, filename, content);

            if (fs_create_file(dirname, filename, (uint8_t*)content, strlen(content)) == 0) {
                print_string("Plik stworzony pomyślnie\n");
            } else {
                print_string("Błąd przy tworzeniu pliku\n");
            }
        } else if (strncmp(command, "read", 4) == 0) {
            char dirname[32];
            char filename[32];
            sscanf(command + 5, "%s %s", dirname, filename);

            struct file* file = fs_find_file(dirname, filename);
            if (file) {
                print_string("Zawartość pliku: ");
                print_string((char*)file->content);
                print_string("\n");
            } else {
                print_string("Plik nie znaleziony\n");
            }
        } else {
            print_string("Nieznana komenda, wpisz 'help' po więcej informacji\n");
        }

        print_string("CyberOS My> ");
    }
}
