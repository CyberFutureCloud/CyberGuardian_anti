#include <stdint.h>
#include "applications.h"
#include "utils.h"

extern uint8_t wallpaper_image[];

void kernel_main(void) {
    // Dodanie opcji uruchomienia w trybie bezpiecznym
    char choice;
    print_string("Wybierz tryb uruchomienia (N: Normalny, B: Bezpieczny): ");
    choice = get_char();
    
    if (choice == 'B' || choice == 'b') {
        safe_mode_init();
    } else {
        // Normalne uruchomienie systemu
        fs_init();
        memory_init((void*)0x100000, 0x400000);
        keyboard_init();
        mouse_init();
        network_init();
        sound_init();
        printer_init();
        bluetooth_init();
        set_wallpaper(wallpaper_image);
        
        // Google Authentication
        print_string("Czy chcesz zalogować się do Google? (T: Tak, N: Nie): ");
        char auth_choice = get_char();
        if (auth_choice == 'T' || auth_choice == 't') {
            google_auth();
        } else {
            print_string("Pominięto autoryzację Google.\n");
        }

        connect_to_google();
        gui_main();
        process_create(text_editor_main);
        process_create(calculator_main);
        process_create(browser_main);
        process_create(installer_main);
        process_create(calendar_main);
        process_create(email_main);
        process_create(video_player_main);
        process_create(music_player_main);
        process_create(printer_manager_main);
        process_create(notes_main);
        process_create(permissions_manager_main);
        process_create(antivirus_main);
        process_create(bluetooth_manager_main);
        process_create(diagnostics_main);

        while (1) {
            schedule();
        }
    }
}

