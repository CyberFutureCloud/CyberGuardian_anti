
#include "gui.h"

void gui_main() {
    set_video_mode(0x13); // Graphics mode 320x200
    draw_window(10, 10, 200, 100, "Advanced GUI");
}
