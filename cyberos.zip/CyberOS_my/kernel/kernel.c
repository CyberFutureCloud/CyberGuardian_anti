
#include "keyboard.h"
#include "memory.h"
#include "filesystem.h"
#include "gui.h"

void kernel_main() {
    memory_init((void*)0x100000, 0x400000);
    fs_init();
    set_video_mode(0x13); // Graphics mode placeholder
    while (1) {
        // Kernel loop
    }
}
