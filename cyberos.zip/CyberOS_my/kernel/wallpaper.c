#include <stdint.h>

#define SCREEN_WIDTH 320
#define SCREEN_HEIGHT 200
#define FRAMEBUFFER 0xA0000

void set_wallpaper(uint8_t color) {
    uint8_t* framebuffer = (uint8_t*)FRAMEBUFFER;
    for (int y = 0; y < SCREEN_HEIGHT; y++) {
        for (int x = 0; x < SCREEN_WIDTH; x++) {
            framebuffer[y * SCREEN_WIDTH + x] = color;
        }
    }
}
