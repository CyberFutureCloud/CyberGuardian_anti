#include <stdint.h>

#define MAX_PROCESSES 256

struct process {
    uint32_t pid;
    void (*entry)(void);
    struct process* next;
    uint32_t* page_directory;
};

static struct process* process_queue[MAX_PROCESSES];
static uint32_t process_count = 0;
static uint32_t current_process = 0;

void process_add(void (*entry)(void)) {
    if (process_count >= MAX_PROCESSES) {
        return; // Brak miejsca na więcej procesów
    }

    struct process* proc = (struct process*)memory_alloc();
    proc->pid = process_count;
    proc->entry = entry;
    proc->next = NULL;
    proc->page_directory = create_page_directory();

    process_queue[process_count++] = proc;
}

void schedule() {
    current_process = (current_process + 1) % process_count;
    struct process* proc = process_queue[current_process];
    load_page_directory(proc->page_directory);
    proc->entry();
}
