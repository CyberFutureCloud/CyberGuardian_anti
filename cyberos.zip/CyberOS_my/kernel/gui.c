#include <stdint.h>

#define SCREEN_WIDTH 320
#define SCREEN_HEIGHT 200
#define FRAMEBUFFER 0xA0000

void plot_pixel(int x, int y, uint8_t color) {
    uint8_t* framebuffer = (uint8_t*)FRAMEBUFFER;
    framebuffer[y * SCREEN_WIDTH + x] = color;
}

void draw_rect(int x, int y, int width, int height, uint8_t color) {
    for (int i = 0; i < height; i++) {
        for (int j = 0; j < width; j++) {
            plot_pixel(x + j, y + i, color);
        }
    }
}

void draw_button(int x, int y, int width, int height, const char* label) {
    draw_rect(x, y, width, height, 15); // Biały prostokąt
    // Dodajemy etykietę (prostym tekstem)
}

void draw_window(int x, int y, int width, int height, const char* title) {
    draw_rect(x, y, width, height, 8); // Szary prostokąt
    draw_rect(x, y, width, 20, 15);    // Pasek tytułu
    // Dodajemy tytuł (prostym tekstem)
}

void gui_main() {
    set_video_mode(0x13); // Tryb graficzny 320x200 256 kolorów
    draw_window(50, 50, 200, 100, "CyberOS My Window");
    draw_button(70, 100, 60, 20, "Click Me");

    while (1) {
        // Nieskończona pętla, aby utrzymać tryb graficzny
    }
}
