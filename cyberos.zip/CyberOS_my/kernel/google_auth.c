#include <stdint.h>
#include <string.h>
#include "network.h"

void google_auth() {
    char username[128];
    char password[128];

    draw_window(10, 10, 300, 180, "Google Authentication");
    print_string("Zaloguj sie do swojego konta Google.\n");

    print_string("Username: ");
    gets(username);
    print_string("Password: ");
    gets(password);

    // Symulacja wysyłania danych logowania do Google
    char auth_data[256];
    snprintf(auth_data, 256, "USERNAME: %s\nPASSWORD: %s", username, password);
    network_send(auth_data, strlen(auth_data));

    char response[256];
    network_receive(response, sizeof(response));

    if (strcmp(response, "Success") == 0) {
        print_string("Autoryzacja zakonczona sukcesem.\n");
    } else {
        print_string("Autoryzacja nieudana.\n");
    }
}
