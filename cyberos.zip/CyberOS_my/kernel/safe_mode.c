#include <stdint.h>

void safe_mode_init() {
    print_string("Uruchamianie w trybie bezpiecznym...\n");
    // Tutaj dodajemy kod uruchamiania minimalnych sterowników i funkcji
}

void kernel_main(void) {
    // Dodanie opcji uruchomienia w trybie bezpiecznym
    char choice;
    print_string("Wybierz tryb uruchomienia (N: Normalny, B: Bezpieczny): ");
    choice = get_char();
    
    if (choice == 'B' || choice == 'b') {
        safe_mode_init();
    } else {
        // Normalne uruchomienie systemu
        fs_init();
        memory_init((void*)0x100000, 0x400000);
        keyboard_init();
        mouse_init();
        network_init();
        set_wallpaper(wallpaper_image);
        connect_to_google();
        gui_main();
        process_create(text_editor_main);
        process_create(calculator_main);
        process_create(browser_main);
        process_create(installer_main);
        process_create(calendar_main);
        process_create(email_main);
        process_create(video_player_main);
        while (1) {
            schedule();
        }
    }
}
