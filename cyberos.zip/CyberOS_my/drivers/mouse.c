#include <stdint.h>
#include <stddef.h>
#include "ports.h"

#define MOUSE_PORT 0x60

void mouse_handler() {
    uint8_t status = inb(MOUSE_PORT);
    // Przetwarzaj status myszy
}

void mouse_init() {
    // Inicjalizacja myszy
    outb(0x64, 0xA8); // Włącz mysz
    outb(0x64, 0xD4);
    outb(0x60, 0xF4); // Włącz raportowanie myszy

    // Zarejestruj handler przerwania myszy
    register_interrupt_handler(IRQ12, mouse_handler);
}

