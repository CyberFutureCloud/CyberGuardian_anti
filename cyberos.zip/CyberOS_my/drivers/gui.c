
#include "gui.h"

void set_video_mode(int mode) {
    // Set video mode placeholder
}

void draw_window(int x, int y, int width, int height, const char* title) {
    // Draw window placeholder
}
