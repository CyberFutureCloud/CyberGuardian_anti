#include <stdint.h>
#include <stddef.h>
#include "ports.h"
#include "keyboard_map.h"
#include "bios.h"
#include "terminal.h"

#define KEYBOARD_PORT 0x60
#define KEYBOARD_STATUS_PORT 0x64

volatile char key_buffer[256];
volatile uint8_t key_buffer_index = 0;
volatile uint8_t ctrl_pressed = 0;
volatile uint8_t shift_pressed = 0;

void keyboard_handler() {
    uint8_t scancode = inb(KEYBOARD_PORT);

    if (scancode & 0x80) {
        // Key released
        if (scancode == 0x9D) { // Ctrl key released
            ctrl_pressed = 0;
        } else if (scancode == 0xAA) { // Shift key released
            shift_pressed = 0;
        }
    } else {
        // Key pressed
        if (scancode == 0x1D) { // Ctrl key pressed
            ctrl_pressed = 1;
        } else if (scancode == 0x2A) { // Shift key pressed
            shift_pressed = 1;
        } else {
            char key = keyboard_map[scancode];
            key_buffer[key_buffer_index++] = key;
            key_buffer[key_buffer_index] = '\0';

            // Skróty klawiszowe
            if (ctrl_pressed && shift_pressed && key == 'B') {
                // Wejście do BIOS-u
                bios_main();
            } else if (ctrl_pressed && shift_pressed && key == 'T') {
                // Wejście do terminala
                terminal_main();
            }
        }
    }
}

char get_char() {
    if (key_buffer_index > 0) {
        char c = key_buffer[0];
        for (int i = 0; i < key_buffer_index; i++) {
            key_buffer[i] = key_buffer[i + 1];
        }
        key_buffer_index--;
        return c;
    }
    return '\0';
}

void keyboard_init() {
    // Zarejestruj handler przerwania klawiatury
    register_interrupt_handler(IRQ1, keyboard_handler);
}

