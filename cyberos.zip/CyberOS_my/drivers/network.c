#include <stdint.h>
#include <stdio.h>
#include "ethernet_driver.h"  // Sterownik karty sieciowej

// Funkcja inicjalizująca kartę sieciową
void network_init() {
    // Inicjalizowanie sterownika karty sieciowej
    if (ethernet_init() != 0) {
        print_string("Błąd inicjalizacji karty sieciowej.\n");
        return;
    }

    // Ustawienie karty sieciowej (adres MAC, konfiguracja protokołów, itp.)
    ethernet_configure();

    // Ustawienie trybu pracy, np. DHCP lub statycznego IP
    if (ethernet_dhcp()) {
        print_string("Uzyskano adres IP przez DHCP.\n");
    } else {
        print_string("Błąd uzyskiwania adresu IP przez DHCP. Ustawienia statyczne.\n");
        ethernet_set_static_ip("192.168.1.100", "255.255.255.0", "192.168.1.1");
    }

    // Połączenie sieciowe zostało pomyślnie nawiązane
    print_string("Połączenie z siecią pomyślnie ustanowione.\n");
}
