#include <stdint.h>

#define MAX_USERS 10
#define MAX_FILES 128

struct user {
    char username[32];
    uint8_t permissions[MAX_FILES];
};

struct filesystem {
    struct file files[MAX_FILES];
    uint32_t file_count;
};

static struct user users[MAX_USERS];
static struct filesystem fs;

struct user* find_user(const char* username) {
    for (int i = 0; i < MAX_USERS; i++) {
        if (strcmp(users[i].username, username) == 0) {
            return &users[i];
        }
    }
    return NULL; // Użytkownik nie znaleziony
}

int fs_create_file(const char* username, const char* file_name, const uint8_t* content, uint32_t size) {
    struct user* user = find_user(username);
    if (!user) {
        return -1; // Użytkownik nie znaleziony
    }

    if (fs.file_count >= MAX_FILES || size > FILE_CONTENT_SIZE) {
        return -1; // Brak miejsca na więcej plików
    }

    struct file* new_file = &fs.files[fs.file_count++];
    strncpy(new_file->name, file_name, FILENAME_LEN);
    memcpy(new_file->content, content, size);
    new_file->size = size;

    // Ustaw uprawnienia
    user->permissions[fs.file_count - 1] = 1;

    return 0;
}

int fs_read_file(const char* username, const char* file_name, uint8_t* buffer) {
    struct user* user = find_user(username);
    if (!user) {
        return -1; // Użytkownik nie znaleziony
    }

    struct file* file = fs_find_file(file_name);
    if (!file) {
        return -1; // Plik nie znaleziony
    }

    uint32_t file_index = file - fs.files;
    if (!user->permissions[file_index]) {
        return -1; // Brak uprawnień
    }

    memcpy(buffer, file->content, file->size);
    return file->size;
}
