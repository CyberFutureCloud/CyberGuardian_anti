#include <stdint.h>
#include <string.h>
#include "keyboard.h"

#define MAX_USERS 10

struct user {
    char username[32];
    char password[32];
};

static struct user users[MAX_USERS];
static int user_count = 0;

void create_account() {
    if (user_count >= MAX_USERS) {
        print_string("Maksymalna liczba kont zostala osiagnieta.\n");
        return;
    }

    char username[32];
    char password[32];

    print_string("Tworzenie nowego konta\n");
    print_string("Podaj nazwe uzytkownika: ");
    gets(username);
    print_string("Podaj haslo: ");
    gets(password);

    strncpy(users[user_count].username, username, 32);
    strncpy(users[user_count].password, password, 32);
    user_count++;

    print_string("Konto zostalo stworzone pomyslnie.\n");
}

void login() {
    char username[32];
    char password[32];

    print_string("Logowanie\n");
    print_string("Podaj nazwe uzytkownika: ");
    gets(username);
    print_string("Podaj haslo: ");
    gets(password);

    for (int i = 0; i < user_count; i++) {
        if (strncmp(users[i].username, username, 32) == 0 && strncmp(users[i].password, password, 32) == 0) {
            print_string("Zalogowano pomyslnie.\n");
            return;
        }
    }

    print_string("Niepoprawna nazwa uzytkownika lub haslo.\n");
}
