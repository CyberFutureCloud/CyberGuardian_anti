#include <stdint.h>
#include <string.h>
#include "filesystem.h"

// Baza danych sygnatur wirusów (symulacja)
const char* virus_signatures[] = {
    "VIRUS_SIG_1",  // Przykładowa sygnatura wirusa
    "VIRUS_SIG_2",  // Kolejna sygnatura
    "VIRUS_SIG_3",  // I jeszcze jedna sygnatura
};

// Funkcja skanująca plik
void scan_file(const char* directory_name, const char* file_name) {
    struct file* file = fs_find_file(directory_name, file_name);
    if (!file) {
        print_string("Plik nie znaleziony.\n");
        return;
    }
    
    // Symulacja skanowania pliku
    print_string("Skanowanie pliku...\n");
    
    // Wczytanie zawartości pliku (symulacja)
    uint8_t* file_data = file->data;  // Zawartość pliku
    uint32_t file_size = file->size;  // Rozmiar pliku
    
    // Symulacja analizy - sprawdzenie sygnatur wirusów w pliku
    for (int i = 0; i < sizeof(virus_signatures) / sizeof(virus_signatures[0]); i++) {
        if (memmem(file_data, file_size, virus_signatures[i], strlen(virus_signatures[i]))) {
            print_string("Znaleziono wirusa! Sygnatura: ");
            print_string(virus_signatures[i]);
            return;  // W przypadku znalezienia wirusa, kończymy skanowanie
        }
    }
    
    print_string("Skanowanie zakończone. Plik jest bezpieczny.\n");
}

// Funkcja do skanowania katalogu
void scan_directory(const char* directory_name) {
    // Przechodzenie po plikach w katalogu (symulacja)
    print_string("Skanowanie katalogu...\n");
    
    // Wyszukiwanie wszystkich plików w katalogu
    struct file* file = fs_find_first_file(directory_name);
    while (file) {
        scan_file(directory_name, file->name);  // Skanowanie każdego pliku
        file = fs_find_next_file(directory_name);  // Przechodzimy do następnego pliku
    }
    
    print_string("Skanowanie katalogu zakończone.\n");
}

// Główna funkcja aplikacji antywirusowej
void antivirus_main() {
    draw_window(10, 10, 300, 180, "CyberOS My Antivirus");
    print_string("Witaj w antywirusie CyberOS My!\n");
    
    char directory[32];
    char filename[32];
    char option;
    
    while (1) {
        print_string("Wybierz opcję:\n");
        print_string("1. Skanowanie pliku\n");
        print_string("2. Skanowanie katalogu\n");
        print_string("3. Zakończ\n");
        option = get_char();  // Wybór opcji
        
        switch(option) {
            case '1':  // Skanowanie pojedynczego pliku
                print_string("Podaj katalog: ");
                gets(directory);
                print_string("Podaj nazwę pliku: ");
                gets(filename);
                scan_file(directory, filename);
                break;
            case '2':  // Skanowanie całego katalogu
                print_string("Podaj katalog do skanowania: ");
                gets(directory);
                scan_directory(directory);
                break;
            case '3':  // Zakończenie programu
                print_string("Zamykanie antywirusa...\n");
                return;  // Zakończenie programu
            default:
                print_string("Nieznana opcja. Spróbuj ponownie.\n");
        }
    }
}
