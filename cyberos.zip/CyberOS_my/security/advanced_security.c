#include <stdint.h>

#define MAX_PROCESSES 256

struct process {
    uint32_t pid;
    uint32_t* page_directory;
    // Inne pola procesu
};

static struct process processes[MAX_PROCESSES];
static uint32_t process_count = 0;

void process_create(void (*entry)(void)) {
    struct process* proc = &processes[process_count++];
    proc->pid = process_count;
    proc->page_directory = create_page_directory();
    // Inicjalizacja innych pól procesu
}

void switch_to_process(uint32_t pid) {
    struct process* proc = &processes[pid];
    load_page_directory(proc->page_directory);
    // Przełącz kontekst do nowego procesu
}
