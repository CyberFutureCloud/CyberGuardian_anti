#include <stdint.h>
#include <string.h>
#include "gui.h"

// Maksymalna liczba użytkowników i uprawnień
#define MAX_USERS 10
#define MAX_PERMISSIONS 100

// Struktura użytkownika
struct user {
    char username[32];
    uint8_t permissions[MAX_PERMISSIONS];
};

static struct user users[MAX_USERS];
static int user_count = 0;

// Funkcja do znalezienia użytkownika po nazwie
struct user* find_user(const char* username) {
    for (int i = 0; i < user_count; i++) {
        if (strcmp(users[i].username, username) == 0) {
            return &users[i];
        }
    }
    return NULL;
}

// Funkcja do przyznawania uprawnienia
void grant_permission(const char* username, uint8_t permission) {
    struct user* user = find_user(username);
    if (user) {
        user->permissions[permission] = 1;
    }
}

// Funkcja do odbierania uprawnienia
void revoke_permission(const char* username, uint8_t permission) {
    struct user* user = find_user(username);
    if (user) {
        user->permissions[permission] = 0;
    }
}

// Funkcja do sprawdzania uprawnień
int has_permission(const char* username, uint8_t permission) {
    struct user* user = find_user(username);
    if (user) {
        return user->permissions[permission];
    }
    return 0;
}

// Funkcja do wyświetlania uprawnień użytkownika
void display_permissions(const char* username) {
    struct user* user = find_user(username);
    if (user) {
        print_string("Uprawnienia użytkownika:\n");
        for (int i = 0; i < MAX_PERMISSIONS; i++) {
            if (user->permissions[i] == 1) {
                print_string("Uprawnienie %d: TAK\n", i);
            }
        }
    } else {
        print_string("Użytkownik nie znaleziony.\n");
    }
}

// Główna funkcja zarządzania uprawnieniami
void permissions_manager_main() {
    draw_window(10, 10, 300, 180, "CyberOS My Permissions Manager");
    print_string("Witaj w menedżerze uprawnień CyberOS My!\n");
    
    char username[32];
    uint8_t permission;
    char option;

    while (1) {
        print_string("Wybierz opcję:\n");
        print_string("1. Przyznaj uprawnienie\n");
        print_string("2. Odbierz uprawnienie\n");
        print_string("3. Sprawdź uprawnienie\n");
        print_string("4. Pokaż uprawnienia użytkownika\n");
        print_string("5. Wyjście\n");
        option = get_char();  // Wybór opcji
        
        switch(option) {
            case '1': // Przyznawanie uprawnienia
                print_string("Podaj nazwę użytkownika: ");
                gets(username);
                print_string("Podaj numer uprawnienia: ");
                permission = get_char() - '0';  // Przekształcamy char na liczbę
                grant_permission(username, permission);
                print_string("Uprawnienie zostało przyznane.\n");
                break;
            case '2': // Odbieranie uprawnienia
                print_string("Podaj nazwę użytkownika: ");
                gets(username);
                print_string("Podaj numer uprawnienia: ");
                permission = get_char() - '0';
                revoke_permission(username, permission);
                print_string("Uprawnienie zostało odebrane.\n");
                break;
            case '3': // Sprawdzanie uprawnienia
                print_string("Podaj nazwę użytkownika: ");
                gets(username);
                print_string("Podaj numer uprawnienia: ");
                permission = get_char() - '0';
                if (has_permission(username, permission)) {
                    print_string("Użytkownik ma to uprawnienie.\n");
                } else {
                    print_string("Użytkownik nie ma tego uprawnienia.\n");
                }
                break;
            case '4': // Pokaż uprawnienia użytkownika
                print_string("Podaj nazwę użytkownika: ");
                gets(username);
                display_permissions(username);
                break;
            case '5': // Wyjście z aplikacji
                print_string("Zamykanie menedżera uprawnień...\n");
                return; // Zakończenie programu
            default:
                print_string("Nieznana opcja. Spróbuj ponownie.\n");
        }
    }
}
