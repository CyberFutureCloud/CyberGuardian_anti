#!/bin/bash

set -e

# �cie�ka do katalogu nag��wk�w
INCLUDE_PATH="-Iinclude"

echo "Kompilacja bootloadera..."
nasm -f bin bootloader.asm -o bootloader.bin

echo "Kompilacja kernela..."
gcc -ffreestanding $INCLUDE_PATH -c kernel/kernel.c -o kernel.o
gcc -ffreestanding $INCLUDE_PATH -c kernel/advanced_gui.c -o advanced_gui.o
gcc -ffreestanding $INCLUDE_PATH -c kernel/gogle_auth.c -o gogle_auth.o
gcc -ffreestanding $INCLUDE_PATH -c kernel/main.c -o main.o
gcc -ffreestanding $INCLUDE_PATH -c kernel/safe_mode.c -o safe_mode.o
gcc -ffreestanding $INCLUDE_PATH -c kernel/scheduler.c -o scheduler.o
gcc -ffreestanding $INCLUDE_PATH -c kernel/setup.c -o setup.o
gcc -ffreestanding $INCLUDE_PATH -c kernel/ui.c -o ui.o
gcc -ffreestanding $INCLUDE_PATH -c kernel/wallpaper.c -o wallpaper.o

echo "Kompilacja aplikacji..."
gcc -ffreestanding $INCLUDE_PATH -c applications/text_editor.c -o text_editor.o
gcc -ffreestanding $INCLUDE_PATH -c applications/calculator.c -o calculator.o
gcc -ffreestanding $INCLUDE_PATH -c applications/browser.c -o browser.o
gcc -ffreestanding $INCLUDE_PATH -c applications/video_player.c -o video_player.o
gcc -ffreestanding $INCLUDE_PATH -c applications/terminal.c -o terminal.o

echo "Kompilacja sterownik�w..."
gcc -ffreestanding $INCLUDE_PATH -c drivers/gui.c -o gui.o
gcc -ffreestanding $INCLUDE_PATH -c drivers/keyboard.c -o keyboard.o
gcc -ffreestanding $INCLUDE_PATH -c drivers/mouse.c -o mouse.o
gcc -ffreestanding $INCLUDE_PATH -c drivers/network.c -o network.o

echo "Kompilacja systemu plik�w..."
gcc -ffreestanding $INCLUDE_PATH -c filesystem/filesystem.c -o filesystem.o

echo "Kompilacja pami�ci..."
gcc -ffreestanding $INCLUDE_PATH -c memory/memory.c -o memory.o

echo "Kompilacja modu��w bezpiecze�stwa..."
gcc -ffreestanding $INCLUDE_PATH -c security/security.c -o security.o

echo "��czenie plik�w obiektowych kernela..."
ld -Ttext 0x1000 -o kernel.bin kernel.o advanced_gui.o gogle_auth.o gui.o text_editor.o calculator.o browser.o video_player.o terminal.o keyboard.o mouse.o network.o filesystem.o memory.o security.o --oformat binary

echo "Tworzenie obrazu dysku..."
cat bootloader.bin kernel.bin > CyberOS_My.bin

echo "Kompilacja zako�czona sukcesem!"
