#ifndef UTILS_H
#define UTILS_H

void print_string(const char* str);
char get_char();
void google_auth();
void safe_mode_init();
void connect_to_google();
void gui_main();
void schedule();

#endif
