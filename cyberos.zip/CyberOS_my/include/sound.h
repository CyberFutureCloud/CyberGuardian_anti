#ifndef SOUND_H
#define SOUND_H

void sound_init();

#endif