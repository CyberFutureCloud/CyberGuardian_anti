#ifndef SECURITY_H
#define SECURITY_H

void login();

#endif