#ifndef PRINTER_H
#define PRINTER_H

void printer_init();

#endif