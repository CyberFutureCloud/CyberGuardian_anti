#ifndef APPLICATIONS_H
#define APPLICATIONS_H

void text_editor_main();
void calculator_main();
void browser_main();
void installer_main();
void calendar_main();
void email_main();
void video_player_main();
void music_player_main();
void printer_manager_main();
void notes_main();
void permissions_manager_main();
void antivirus_main();
void bluetooth_manager_main();
void diagnostics_main();

#endif
