
#ifndef KEYBOARD_H
#define KEYBOARD_H

char get_char();

#endif
