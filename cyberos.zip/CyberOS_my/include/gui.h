
#ifndef GUI_H
#define GUI_H

void set_video_mode(int mode);
void draw_window(int x, int y, int width, int height, const char* title);

#endif
