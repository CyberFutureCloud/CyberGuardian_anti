#ifndef NETWORK_H
#define NETWORK_H

void network_init();

#endif