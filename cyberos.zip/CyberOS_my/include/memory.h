#ifndef MEMORY_H
#define MEMORY_H

#include <stddef.h> // Dodanie <stddef.h> dla size_t

void memory_init(void* start, size_t size);

#endif
