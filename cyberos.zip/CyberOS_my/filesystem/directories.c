#include <stdint.h>
#include <string.h>

#define MAX_FILES 128
#define FILENAME_LEN 32
#define FILE_CONTENT_SIZE 1024
#define MAX_DIRECTORIES 128
#define DIRECTORY_NAME_LEN 32

struct file {
    char name[FILENAME_LEN];
    uint8_t content[FILE_CONTENT_SIZE];
    uint32_t size;
};

struct directory {
    char name[DIRECTORY_NAME_LEN];
    struct file files[MAX_FILES];
    uint32_t file_count;
};

struct filesystem {
    struct directory directories[MAX_DIRECTORIES];
    uint32_t directory_count;
};

static struct filesystem fs;

void fs_init() {
    fs.directory_count = 0;
}

int fs_create_directory(const char* name) {
    if (fs.directory_count >= MAX_DIRECTORIES) {
        return -1; // Brak miejsca na więcej katalogów
    }

    struct directory* new_directory = &fs.directories[fs.directory_count++];
    strncpy(new_directory->name, name, DIRECTORY_NAME_LEN);
    new_directory->file_count = 0;

    return 0;
}

int fs_create_file(const char* directory_name, const char* file_name, const uint8_t* content, uint32_t size) {
    for (uint32_t i = 0; i < fs.directory_count; i++) {
        if (strncmp(fs.directories[i].name, directory_name, DIRECTORY_NAME_LEN) == 0) {
            if (fs.directories[i].file_count >= MAX_FILES || size > FILE_CONTENT_SIZE) {
                return -1; // Brak miejsca na więcej plików
            }

            struct file* new_file = &fs.directories[i].files[fs.directories[i].file_count++];
            strncpy(new_file->name, file_name, FILENAME_LEN);
            memcpy(new_file->content, content, size);
            new_file->size = size;

            return 0;
        }
    }
    return -1; // Katalog nie znaleziony
}

struct file* fs_find_file(const char* directory_name, const char* file_name) {
    for (uint32_t i = 0; i < fs.directory_count; i++) {
        if (strncmp(fs.directories[i].name, directory_name, DIRECTORY_NAME_LEN) == 0) {
            for (uint32_t j = 0; j < fs.directories[i].file_count; j++) {
                if (strncmp(fs.directories[i].files[j].name, file_name, FILENAME_LEN) == 0) {
                    return &fs.directories[i].files[j];
                }
            }
        }
    }
    return NULL; // Plik nie znaleziony
}
