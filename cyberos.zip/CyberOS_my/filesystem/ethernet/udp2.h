#include "udp.h"  // Zakładając, że masz implementację UDP

// Funkcja do wysyłania danych przez sieć
void network_send(const char* data, uint32_t size, const char* ip, uint16_t port) {
    // Tworzymy datagram UDP
    udp_packet_t packet;
    packet.data = (uint8_t*)data;
    packet.size = size;
    packet.dst_ip = ip;  // Adres IP odbiorcy
    packet.dst_port = port;  // Port odbiorcy

    // Wysyłanie pakietu UDP
    if (udp_send(&packet) != 0) {
        print_string("Błąd podczas wysyłania danych.\n");
    } else {
        print_string("Dane zostały wysłane pomyślnie.\n");
    }
}
