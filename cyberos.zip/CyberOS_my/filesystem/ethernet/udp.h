#include "udp.h"  // Zakładając, że masz implementację UDP

// Funkcja do odbierania danych z sieci
void network_receive(char* buffer, uint32_t size) {
    // Tworzymy strukturę dla odebranego pakietu UDP
    udp_packet_t packet;
    packet.data = (uint8_t*)buffer;
    packet.size = size;

    // Odbieramy pakiet UDP
    if (udp_receive(&packet) != 0) {
        print_string("Błąd podczas odbierania danych.\n");
    } else {
        print_string("Dane zostały odebrane.\n");
        // Tutaj możesz przetwarzać odebrane dane
    }
}
